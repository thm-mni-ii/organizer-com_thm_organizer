<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_thm_organizer
 * @description main component controller
 * @author      James Antrim jamesDOTantrimATmniDOTthmDOTde
 * @copyright   TH Mittelhessen 2012
 * @license     GNU GPL v.2
 * @link        www.mni.thm.de
 * @version     2.5
 */

defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.controller');

class thm_organizerController extends JController
{
    function display() {  parent::display(); }
} 
