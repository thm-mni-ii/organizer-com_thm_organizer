<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_thm_organizer
 * @name        semester manager view
 * @description organizes data from the model to use in the template
 * @author      James Antrim jamesDOTantrimATyahooDOTcom
 * @copyright   TH Mittelhessen 2011
 * @license     GNU GPL v.2
 * @link        www.mni.thm.de
 * @version     1.7.0
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view');
require_once JPATH_COMPONENT.'/assets/helpers/thm_organizerHelper.php';

class thm_organizersViewsemester_manager extends JView
{
    public function display($tpl = null)
    {
        if(!JFactory::getUser()->authorise('core.admin'))
            return JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));

        $document = & JFactory::getDocument();
        $document->addStyleSheet($this->baseurl."/components/com_thm_organizer/assets/css/thm_organizer.css");

        $model = $this->getModel();
        $this->semesters = $model->semesters;
        $this->addToolBar();

        parent::display($tpl);
    }

    private function addToolBar()
    {
        JToolBarHelper::title( JText::_( 'COM_THM_ORGANIZER_SEM_TITLE' ), 'generic.png' );
        JToolBarHelper::addNew('semester.add');
        JToolBarHelper::editList('semester.edit');
        JToolBarHelper::deleteList
        (
            JText::_( 'COM_THM_ORGANIZER_SEM_DELETE_CONFIRM'),
            'semester.delete'
        );
    }
}
	